# Self-Hosted Starter Pack - FREE tier

# Self-Hosted Homelab & Automation Starter Pack

**4 production-grade Python scripts + this guide. Zero dependencies. Pure standard
library — no `pip install`, no Flask, no paid tools. Runs on any
Raspberry Pi, VPS, or old laptop with Python 3.8+.**

> Built and battle-tested on a real Raspberry Pi running Pi-hole, WireGuard,
> and a system dashboard — the same setup this pack helps you recreate.

---


---
Full pack (dashboard, wg_peer, cron_task + setup guide) at the paid link.
